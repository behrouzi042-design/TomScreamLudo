package com.sina.tomscreamludo

import android.app.Activity
import android.os.Bundle
import android.graphics.*
import android.media.AudioFormat
import android.media.AudioManager
import android.media.AudioTrack
import android.view.MotionEvent
import android.view.View
import android.widget.*
import kotlin.math.*

class MainActivity : Activity() {
    override fun onCreate(savedInstanceState: Bundle?) {
        super.onCreate(savedInstanceState)
        window.statusBarColor = Color.rgb(23,23,23)
        window.navigationBarColor = Color.rgb(23,23,23)
        val root = LinearLayout(this).apply { orientation = LinearLayout.VERTICAL; setBackgroundColor(Color.rgb(23,23,23)) }
        val title = TextView(this).apply {
            text = "🐱 تام جیغ‌زن لودو"; textSize = 25f; gravity = Gravity.CENTER
            setTextColor(Color.WHITE); setPadding(12,18,12,12)
        }
        root.addView(title)
        val controls = LinearLayout(this).apply { orientation = LinearLayout.HORIZONTAL; gravity = Gravity.CENTER }
        val count = Spinner(this)
        count.adapter = ArrayAdapter(this, android.R.layout.simple_spinner_dropdown_item, listOf("۲ بازیکن","۳ بازیکن","۴ بازیکن"))
        val bots = CheckBox(this).apply { text = "بازی با ربات"; setTextColor(Color.WHITE); buttonTintList = android.content.res.ColorStateList.valueOf(Color.YELLOW) }
        controls.addView(count, LinearLayout.LayoutParams(0, -2, 1f))
        controls.addView(bots, LinearLayout.LayoutParams(0, -2, 1f))
        root.addView(controls)
        val status = TextView(this).apply { text = "نوبت قرمز • تاس بریز"; textSize = 17f; gravity = Gravity.CENTER; setTextColor(Color.WHITE); setPadding(8,8,8,8) }
        root.addView(status)
        val board = LudoView(this) { s -> status.text = s }
        root.addView(board, LinearLayout.LayoutParams(-1, 0, 1f))
        val bottom = LinearLayout(this).apply { gravity = Gravity.CENTER; orientation = LinearLayout.HORIZONTAL }
        val roll = Button(this).apply { text = "🎲 تاس بریز"; setOnClickListener { board.roll() } }
        val reset = Button(this).apply { text = "شروع دوباره"; setOnClickListener { board.setup(count.selectedItemPosition+2, bots.isChecked) } }
        bottom.addView(roll, LinearLayout.LayoutParams(0,-2,1f))
        bottom.addView(reset, LinearLayout.LayoutParams(0,-2,1f))
        root.addView(bottom)
        setContentView(root)
        board.setup(2, false)
        count.onItemSelectedListener = object : android.widget.AdapterView.OnItemSelectedListener {
            override fun onNothingSelected(parent: android.widget.AdapterView<*>?) {}
            override fun onItemSelected(parent: android.widget.AdapterView<*>?, view: View?, position: Int, id: Long) { board.setup(position+2, bots.isChecked) }
        }
        bots.setOnCheckedChangeListener { _, checked -> board.setup(count.selectedItemPosition+2, checked) }
    }
}

private data class Token(var progress: Int = -1)
private class LudoView(ctx: android.content.Context, val message: (String)->Unit) : View(ctx) {
    private val colors = intArrayOf(Color.rgb(220,45,45), Color.rgb(37,165,83), Color.rgb(244,193,36), Color.rgb(47,115,220))
    private val names = arrayOf("قرمز","سبز","زرد","آبی")
    private val starts = intArrayOf(0,13,26,39)
    private val tokens = Array(4) { Array(4) { Token() } }
    private var players=2; private var bots=false; private var current=0; private var dice=0
    private val paint=Paint(3)
    private var boardRect=RectF()
    private var track= mutableListOf<PointF>()
    private val centers=Array(4){ mutableListOf<PointF>() }
    private var hitRects=Array(4){Array(4){RectF()} }
    private var lastRoll=0
    fun setup(n:Int, robot:Boolean) {
        players=n.coerceIn(2,4); bots=robot; current=0; dice=0; lastRoll=0
        for (p in 0..3) for (t in 0..3) tokens[p][t].progress=-1
        message("نوبت ${names[current]} • تاس بریز")
        invalidate()
    }
    fun roll() {
        if (bots && current==1) return
        if (dice!=0) { message("اول یکی از مهره‌های روشن‌شده را لمس کن"); return }
        dice=(1..6).random(); lastRoll=dice
        message("🎲 عدد $dice • مهرهٔ قابل حرکت را لمس کن")
        invalidate()
    }
    override fun onDraw(c:Canvas) {
        super.onDraw(c); c.drawColor(Color.rgb(248,246,238))
        val s=min(width,height).toFloat()
        val cell=s/15f; val left=(width-s)/2f; val top=(height-s)/2f
        boardRect=RectF(left,top,left+s,top+s)
        paint.style=Paint.Style.FILL
        c.drawRoundRect(boardRect,18f,18f,paint.apply{color=Color.WHITE})
        // four home bases
        val homeCells=arrayOf(0 to 0, 9 to 0, 9 to 9, 0 to 9)
        for(p in 0..3) {
            val (gx,gy)=homeCells[p]
            val r=RectF(left+gx*cell,top+gy*cell,left+(gx+6)*cell,top+(gy+6)*cell)
            paint.color=colors[p]; c.drawRoundRect(r,cell*.25f,cell*.25f,paint)
            paint.color=Color.WHITE; c.drawRoundRect(RectF(r.left+cell*.65f,r.top+cell*.65f,r.right-cell*.65f,r.bottom-cell*.65f),cell*.25f,cell*.25f,paint)
            centers[p].clear()
            for(i in 0..3) {
                val x=r.left+cell*(1.6f+(i%2)*2.8f); val y=r.top+cell*(1.6f+(i/2)*2.8f)
                centers[p].add(PointF(x,y))
            }
        }
        // central finish
        val cx=left+7.5f*cell; val cy=top+7.5f*cell
        val path=Path().apply { moveTo(cx,cy-cell*2.6f); lineTo(cx+cell*2.6f,cy); lineTo(cx,cy+cell*2.6f); lineTo(cx-cell*2.6f,cy); close() }
        paint.color=Color.LTGRAY; c.drawPath(path,paint)
        // track loop, 52 points around a square ring
        track.clear()
        val raw= arrayListOf<Pair<Float,Float>>()
        // perimeter path centers around 15x15 board
        for(x in 1..13) raw.add(x.toFloat() to 6f)
        for(y in 5 downTo 1) raw.add(13f to y.toFloat())
        for(x in 13 downTo 1) raw.add(x.toFloat() to 1f)
        for(y in 1..5) raw.add(1f to y.toFloat())
        // normalize to 52 by sampled perimeter path
        val loop= mutableListOf<Pair<Float,Float>>()
        // 52-step rectangular circuit: 13 points per side, corners repeated.
        for(x in 1..13) loop.add(x.toFloat() to 1f)
        for(y in 1..13) loop.add(13f to y.toFloat())
        for(x in 13 downTo 1) loop.add(x.toFloat() to 13f)
        for(y in 13 downTo 1) loop.add(1f to y.toFloat())
        val pts=loop.take(52)
        for(i in 0 until 52) {
            val (gx,gy)=pts[i]
            val pt=PointF(left+(gx+.5f)*cell,top+(gy+.5f)*cell); track.add(pt)
            paint.color= if(i in starts) colors[starts.indexOf(i)] else Color.rgb(235,233,224)
            c.drawCircle(pt.x,pt.y,cell*.38f,paint)
            paint.color=Color.GRAY; paint.style=Paint.Style.STROKE; paint.strokeWidth=1f
            c.drawCircle(pt.x,pt.y,cell*.38f,paint); paint.style=Paint.Style.FILL
        }
        // home lanes
        for(p in 0 until players) for(step in 1..5) {
            val (gx,gy)=when(p){0->(1+step) to 7;1->7 to (1+step);2->(13-step) to 7;else->7 to (13-step)}
            paint.color=colors[p]; c.drawRoundRect(left+gx*cell,top+gy*cell,left+(gx+1)*cell,top+(gy+1)*cell,5f,5f,paint)
        }
        // tokens: home or track, then home stretch
        for(p in 0 until players) for(t in 0..3) {
            val prog=tokens[p][t].progress
            val pt= if(prog<0) centers[p][t] else if(prog<52) track[(starts[p]+prog)%52] else {
                val step=(prog-52).coerceIn(0,5)
                val (gx,gy)=when(p){0->(2+step) to 7;1->7 to (2+step);2->(12-step) to 7;else->7 to (12-step)}
                PointF(left+(gx+.5f)*cell,top+(gy+.5f)*cell)
            }
            val rr=cell*.30f
            paint.color=colors[p]; c.drawCircle(pt.x,pt.y,rr,paint)
            paint.color=Color.WHITE; paint.style=Paint.Style.STROKE; paint.strokeWidth=2.5f; c.drawCircle(pt.x,pt.y,rr,paint); paint.style=Paint.Style.FILL
            paint.color=Color.BLACK; paint.textSize=cell*.32f; paint.textAlign=Paint.Align.CENTER
            c.drawText("${t+1}",pt.x,pt.y+cell*.11f,paint)
            hitRects[p][t]=RectF(pt.x-rr,pt.y-rr,pt.x+rr,pt.y+rr)
        }
        // dice panel
        paint.color=Color.rgb(34,34,34); c.drawRoundRect(left+s*.38f,top+s*.43f,left+s*.62f,top+s*.57f,12f,12f,paint)
        paint.color=Color.WHITE; paint.textSize=cell*1.4f; paint.textAlign=Paint.Align.CENTER
        c.drawText(if(dice==0) "🎲" else dice.toString(),cx,cy+cell*.5f,paint)
        paint.textSize=cell*.3f; c.drawText("لمس مهره برای حرکت",cx,top+s*.61f,paint)
    }
    override fun onTouchEvent(e:MotionEvent):Boolean {
        if(e.action!=MotionEvent.ACTION_UP) return true
        if(dice==0) { roll(); return true }
        for(t in 0..3) if(hitRects[current][t].contains(e.x,e.y)) {
            val tok=tokens[current][t]
            if(tok.progress<0) { if(dice!=6){message("برای ورود به بازی باید ۶ بیاوری"); return true}; tok.progress=0 }
            else if(tok.progress+dice>57) { message("این مهره با این عدد به خانه نمی‌رسد"); return true }
            else tok.progress+=dice
            var captured=false
            if(tok.progress<52) {
                val pos=(starts[current]+tok.progress)%52
                if(pos !in starts) for(p in 0 until players) if(p!=current) for(ot in 0..3) {
                    val other=tokens[p][ot]
                    if(other.progress in 0..51 && (starts[p]+other.progress)%52==pos) { other.progress=-1; captured=true }
                }
            }
            val extra=dice==6 || captured
            dice=0
            if(captured) { message("💥 مهره زده شد! جیغ کارتونی!"); scream() }
            if(tok.progress==57) message("${names[current]} یک مهره را به خانه رساند!")
            if(!extra) current=(current+1)%players
            if(bots && current==1) postDelayed({ botTurn() },650)
            else if(!captured) message("نوبت ${names[current]} • تاس بریز")
            invalidate(); return true
        }
        message("مهرهٔ روشن‌شده را لمس کن")
        return true
    }
    private fun botTurn() {
        if(!bots || current!=1) return
        if(dice==0) dice=(1..6).random()
        val movable=(0..3).filter { t -> val p=tokens[current][t].progress; (p<0 && dice==6) || (p>=0 && p+dice<=57) }
        if(movable.isEmpty()) { val wasSix=dice==6; dice=0; if(!wasSix) current=(current+1)%players; invalidate(); if(current==1) postDelayed({botTurn()},450) else message("نوبت ${names[current]} • تاس بریز"); return }
        val t=movable.random(); val tok=tokens[current][t]
        if(tok.progress<0) tok.progress=0 else tok.progress+=dice
        val six=dice==6; dice=0
        if(!six) current=(current+1)%players
        invalidate(); message("نوبت ${names[current]} • تاس بریز")
        if(current==1) postDelayed({botTurn()},450)
    }
    private fun scream() {
        Thread {
            try {
                val sr=22050; val dur=0.48; val n=(sr*dur).toInt()
                val data=ShortArray(n)
                for(i in 0 until n) {
                    val t=i.toDouble()/sr
                    val env=min(1.0,t*28)*max(0.0,1.0-t/dur)
                    val freq=760+520*sin(t*10)+180*sin(t*25)
                    val v=(sin(2*PI*freq*t)+0.35*sin(2*PI*(freq*2.02)*t))*env*10000
                    data[i]=v.toInt().coerceIn(-32768,32767).toShort()
                }
                val at=AudioTrack(AudioManager.STREAM_MUSIC,sr,AudioFormat.CHANNEL_OUT_MONO,AudioFormat.ENCODING_PCM_16BIT,data.size*2,AudioTrack.MODE_STATIC)
                at.write(data,0,data.size); at.play()
                postDelayed({ try { at.stop(); at.release() } catch (_:Exception){} },650)
            } catch (_:Exception) {}
        }.start()
    }
}
